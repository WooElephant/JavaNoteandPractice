package com.augus.entity;

import java.io.Serializable;

public class Student implements Serializable {

    private static final long SerialVersionUID = 1L;

    private int stu_id;
    private String stu_name;
    private String stu_sex;
    private int stu_age;
    private String stu_email;
    private String stu_phone;

    public Student() {
    }

    @Override
    public String toString() {

        return String.format("%-16s",stu_id) + "\t\t" + String.format("%-16s",stu_name) +
                "\t\t" + String.format("%-16s",stu_sex) +
                "\t\t" + String.format("%-16s",stu_age) +
                "\t\t" + String.format("%-16s",stu_phone) +
                "\t\t" + String.format("%-16s",stu_email);
    }

    public static long getSerialVersionUID() {
        return SerialVersionUID;
    }

    public int getStu_id() {
        return stu_id;
    }

    public void setStu_id(int stu_id) {
        this.stu_id = stu_id;
    }

    public String getStu_name() {
        return stu_name;
    }

    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }

    public String getStu_sex() {
        return stu_sex;
    }

    public void setStu_sex(String stu_sex) {
        this.stu_sex = stu_sex;
    }

    public int getStu_age() {
        return stu_age;
    }

    public void setStu_age(int stu_age) {
        this.stu_age = stu_age;
    }

    public String getStu_email() {
        return stu_email;
    }

    public void setStu_email(String stu_email) {
        this.stu_email = stu_email;
    }

    public String getStu_phone() {
        return stu_phone;
    }

    public void setStu_phone(String stu_phone) {
        this.stu_phone = stu_phone;
    }

    public Student(int stu_id, String stu_name, String stu_sex, int stu_age, String stu_email, String stu_phone) {
        this.stu_id = stu_id;
        this.stu_name = stu_name;
        this.stu_sex = stu_sex;
        this.stu_age = stu_age;
        this.stu_email = stu_email;
        this.stu_phone = stu_phone;
    }
}
