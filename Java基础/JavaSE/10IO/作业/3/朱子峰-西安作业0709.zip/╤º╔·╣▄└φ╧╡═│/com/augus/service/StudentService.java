package com.augus.service;

import com.augus.dao.StudentDao;
import com.augus.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;


@Component
public class StudentService {

    @Autowired
    StudentDao studentDao;

    public void init(){
        studentDao.init();
    }

    /**
     * @param req 用HashMap来模拟request作
     */
    public void service01(HashMap<String,String> req){
        int id = Integer.parseInt(req.get("id"));
        String name = req.get("name");
        String sex = req.get("sex");
        int age = Integer.parseInt(req.get("age"));
        String email = req.get("email");
        String phone = req.get("phone");
        Student student = new Student(id,name,sex,age,email,phone);
        studentDao.add(student);
    }

    public void service02(HashMap<String,String> req){
        int id = Integer.parseInt(req.get("id"));
        String name = req.get("name");
        String sex = req.get("sex");
        int age = Integer.parseInt(req.get("age"));
        String email = req.get("email");
        String phone = req.get("phone");
        Student student = new Student(id,name,sex,age,email,phone);
        studentDao.update(student);
    }

    public void service03(HashMap<String,String> req){
        int id = Integer.parseInt(req.get("id"));
        studentDao.remove(id);
    }

    public List<Student> service04(){
        List<Student> list = studentDao.querry();
        return list;
    }


}
