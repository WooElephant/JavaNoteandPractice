package com.augus.view;

import org.springframework.stereotype.Component;

@Component
public class View {
    public static void welcome(){
        System.out.println("==============================================");
        System.out.println("=                                            =");
        System.out.println("=              欢迎使用学生管理系统              =");
        System.out.println("=                                            =");
        System.out.println("==============================================");
    }

    public static void querryHead(){
        String head = String.format("%-23s","学号") +
                String.format("%-22s","姓名") +
                String.format("%-23s","性别") +
                String.format("%-23s","年龄") +
                String.format("%-23s","邮箱") +
                String.format("%-24s","电话");
        System.out.println(head);
    }

    public static void showSelect(){
        System.out.println("请选择：1、添加  2、修改  3、删除  4、查询  0、退出");
    }
}
