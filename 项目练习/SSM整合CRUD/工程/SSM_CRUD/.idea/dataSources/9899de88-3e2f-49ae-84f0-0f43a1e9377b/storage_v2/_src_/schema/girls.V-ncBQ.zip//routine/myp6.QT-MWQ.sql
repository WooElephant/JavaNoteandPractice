create
    definer = root@localhost procedure myp6(IN beautyName varchar(20), OUT boyName varchar(20), OUT boyCP int)
begin
    select bo.boyName , bo.userCP into boyName,boyCP
    from boys bo
    inner join beauty b
    on b.boyfriend_id = bo.id
    where b.name = beautyName;
end;

