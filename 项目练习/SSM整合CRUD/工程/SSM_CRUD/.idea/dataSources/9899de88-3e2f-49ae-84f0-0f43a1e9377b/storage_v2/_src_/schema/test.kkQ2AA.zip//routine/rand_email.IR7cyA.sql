create
    definer = root@localhost function rand_email(n int) returns varchar(100)
begin
        declare chars varchar(255) default 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        declare return_str varchar(100) default '';
        declare i int default 0;
        while i < n do
            set return_str = concat(return_str,substring(chars,floor(1 + rand()*62),1));
            set i = i + 1;
        end while;
        return concat(return_str,'@','yunhe.com');
    end;

