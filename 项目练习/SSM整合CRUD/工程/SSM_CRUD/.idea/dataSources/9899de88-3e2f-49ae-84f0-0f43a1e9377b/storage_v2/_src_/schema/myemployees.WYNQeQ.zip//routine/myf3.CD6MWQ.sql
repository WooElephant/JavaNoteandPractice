create
    definer = root@localhost function myf3(deptName varchar(20)) returns double
begin
    declare sal double;
    select avg(salary) into sal
    from employees e
    join departments d
    on d.department_id = e.department_id
    where department_name = deptName;
    return sal;
end;

