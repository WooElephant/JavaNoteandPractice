package com.augus.dao;

import com.augus.entity.Student;

import java.util.List;

public interface StudentDao {
    public void update(Student student);
    public void add(Student student);
    public void remove(int id);
    public List<Student> querry();
    public void init();
}
