package com.augus.dao.impl;

import com.augus.dao.StudentDao;
import com.augus.entity.Student;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.List;

@Component
public class StudentDaoImpl implements StudentDao {

    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    private String path = "data.dat";


    @Override
    public void update(Student student) {
        try {
            ois = new ObjectInputStream(new FileInputStream(path));
            List<Student> list = (List<Student>) ois.readObject();
            for (int i = 0; i < list.size(); i++) {
                Student temp = list.get(i);
                if (temp.getStu_id() == student.getStu_id()){
                    list.get(i).setStu_name(student.getStu_name());
                    list.get(i).setStu_sex(student.getStu_sex());
                    list.get(i).setStu_age(student.getStu_age());
                    list.get(i).setStu_email(student.getStu_email());
                    list.get(i).setStu_phone(student.getStu_phone());
                }
            }
            oos = new ObjectOutputStream(new FileOutputStream(path));
            oos.writeObject(list);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                ois.close();
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void add(Student student) {
        try {
            ois = new ObjectInputStream(new FileInputStream(path));
            List<Student> list = (List<Student>) ois.readObject();
            list.add(student);
            oos = new ObjectOutputStream(new FileOutputStream(path));
            oos.writeObject(list);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                ois.close();
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void remove(int id) {
        try {
            ois = new ObjectInputStream(new FileInputStream(path));
            List<Student> list = (List<Student>) ois.readObject();
            for (int i = 0; i < list.size(); i++) {
                Student temp = list.get(i);
                if (temp.getStu_id() == id){
                    list.remove(i);
                }
            }
            oos = new ObjectOutputStream(new FileOutputStream(path));
            oos.writeObject(list);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                ois.close();
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<Student> querry() {
        List<Student> list = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(path));
            list = (List<Student>) ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @Override
    public void init() {
        List<Student> list = null;
        list.add(new Student(1001,"张三","男",18,"zhangsan@qq.com","13110011001"));
        list.add(new Student(1002,"李四","男",19,"lisi@qq.com","13110021002"));
        list.add(new Student(1003,"王五","男",20,"wangwu@qq.com","13110031003"));
        try {
            oos = new ObjectOutputStream(new FileOutputStream(path));
            oos.writeObject(list);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
