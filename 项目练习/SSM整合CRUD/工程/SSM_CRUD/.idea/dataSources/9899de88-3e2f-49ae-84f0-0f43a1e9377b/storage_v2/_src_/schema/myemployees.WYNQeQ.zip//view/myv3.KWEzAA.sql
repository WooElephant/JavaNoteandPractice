create definer = root@localhost view myv3 as
select avg(`myemployees`.`employees`.`salary`) AS `avg(salary)`, `myemployees`.`employees`.`job_id` AS `job_id`
from `myemployees`.`employees`
group by `myemployees`.`employees`.`job_id`;

