create
    definer = root@localhost procedure myp3(IN username varchar(20), IN password varchar(10))
begin
    declare result int default 0;

    select count(*) into result
    from admin
    where admin.username = username and admin.password = password;

    select if(result>0,'成功','失败');
end;

