create definer = root@localhost view v1 as
select `s`.`stuName` AS `stuName`, `m`.`majorName` AS `majorName`
from (`students`.`stuinfo` `s`
         join `students`.`major` `m` on ((`m`.`id` = `s`.`majorId`)));

