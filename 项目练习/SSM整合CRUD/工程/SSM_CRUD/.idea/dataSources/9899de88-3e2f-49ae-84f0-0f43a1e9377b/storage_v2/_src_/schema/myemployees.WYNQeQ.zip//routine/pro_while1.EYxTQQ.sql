create
    definer = root@localhost procedure pro_while1(IN insertCount int)
begin
    declare i int default 1;
    while i<=insertCount do
        insert into admin(username, password)
        values ('rose'+i,'666');
        set i = i + 1;
        end while;
end;

