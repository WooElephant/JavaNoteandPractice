create
    definer = root@localhost function test_if(score int) returns char
begin
    if score >= 90 and score <= 100 then return 'A';
    elseif score >= 80 then return 'B';
    elseif score >= 60 then return 'C';
    else return 'D';
    end if;
end;

