create
    definer = root@localhost function myf2(empName varchar(20)) returns double
begin
    set @sal = 0;
    select salary into @sal
    from employees
    where last_name = empName;
    return @sal;
end;

