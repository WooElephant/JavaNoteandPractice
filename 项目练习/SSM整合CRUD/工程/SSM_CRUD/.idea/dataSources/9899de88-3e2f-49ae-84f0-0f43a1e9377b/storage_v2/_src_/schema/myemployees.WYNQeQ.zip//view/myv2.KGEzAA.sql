create definer = root@localhost view myv2 as
select avg(`myemployees`.`employees`.`salary`) AS `ag`, `myemployees`.`employees`.`department_id` AS `department_id`
from `myemployees`.`employees`
group by `myemployees`.`employees`.`department_id`;

