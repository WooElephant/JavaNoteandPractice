import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Homework1 {

    private String path = "data.dat";

    /**
     * DataOut
     */
    @Test
    public void Homework1_DataOut(){
        List<Student> list = new ArrayList<>();
        list.add(new Student("张三",17,"实验"));
        list.add(new Student("李四",16,"师大"));
        list.add(new Student("王五",15,"兴华"));
        list.add(new Student("赵六",14,"理工"));
        list.add(new Student("孙七",13,"一中"));
        DataOutputStream dos = null;

        try {
            dos = new DataOutputStream(new FileOutputStream(path));
            for (Student student : list) {
                dos.writeUTF(student.getName());
                dos.writeInt(student.getAge());
                dos.writeUTF(student.getSchool_name());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                dos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @Test
    public void Homework1_DataIn(){
        List<Student> list = new ArrayList<>();
        DataInputStream dis = null;
        try {
            dis = new DataInputStream(new FileInputStream(path));
            for (int i = 0; i < 5; i++) {
                String name = dis.readUTF();
                int age = dis.readInt();
                String school = dis.readUTF();
                Student student = new Student(name, age, school);
                list.add(student);
            }
            for (Student student : list) {
                System.out.println(student);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void Homework2_ObjectOut(){
        List<Student> list = new ArrayList<>();
        list.add(new Student("张三",17,"实验"));
        list.add(new Student("李四",16,"师大"));
        list.add(new Student("王五",15,"兴华"));
        list.add(new Student("赵六",14,"理工"));
        list.add(new Student("孙七",13,"一中"));
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(path));
            oos.writeObject(list);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void Homework2_ObjectIn(){
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(path));
            List list = (List) ois.readObject();
            for (Object o : list) {
                System.out.println(o);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
