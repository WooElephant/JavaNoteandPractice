import java.io.Serializable;

public class Student implements Serializable {

    private static final long SerialVersionUID = 1L;

    private String name;
    private int age;
    private String school_name;

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", school_name='" + school_name + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSchool_name() {
        return school_name;
    }

    public void setSchool_name(String school_name) {
        this.school_name = school_name;
    }

    public Student(String name, int age, String school_name) {
        this.name = name;
        this.age = age;
        this.school_name = school_name;
    }

    public Student() {
    }
}
