create
    definer = root@localhost procedure myp5(IN beautyName varchar(20), OUT boyName varchar(20))
begin
    select bo.boyName into boyName
    from boys bo
    inner join beauty b
    on b.boyfriend_id = bo.id
    where b.name = beautyName;
end;

